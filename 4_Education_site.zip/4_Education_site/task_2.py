#!/usr/bin/python3

from bs4 import BeautifulSoup
import pandas as pd
import html5lib
import codecs
import re
import os
from config import config
import sys
import urllib3
import time

'''
PURPOSE : As per task.txt
'''

url_1 = config.url_1
url_2 = config.url_2
url_3 = config.url_3
url_4 = config.url_4
url_5 = config.url_5
url_6 = config.url_6
url_7 = config.url_7
url_8 = config.url_8
url_9 = config.url_9
url_10 = config.url_10
url_11 = config.url_11
url_12 = config.url_12


def mytable(baseurl,filename):

    http = urllib3.PoolManager()
    response = http.request('GET', baseurl)
    soup = BeautifulSoup(response.data.decode('utf-8'),"lxml")
    table = soup.find_all('table')[0] # Grab the first table
    mytable = codecs.open(filename, "w", encoding="utf8")
    mytable.write(str(table))
    phone = soup.find_all("h2",{"class":"Heading-2"})
    #print (phone[2].text)


mytable(url_1,"arts.html")
mytable(url_2,"cte.html")
mytable(url_3,"english.html")
mytable(url_4,"ec.html")
mytable(url_5,"foreignlanguage.html")
mytable(url_6,"math.html")
mytable(url_7,"rotc.html")
mytable(url_8,"pe.html")
mytable(url_9,"science.html")
mytable(url_10,"socialstudies.html")
mytable(url_11,"studentservices.html")
mytable(url_12,"supportstaff.html")

os.system('./html_csv.sh')

















