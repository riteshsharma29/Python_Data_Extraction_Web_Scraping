#! /usr/bin/python3

import pandas as pd
from pandas import ExcelWriter
from openpyxl import load_workbook
from openpyxl import __version__
import codecs
import sys
import os

''''
Ubuntu 18.10
python3
'''


print ("")
print ("")
print ("")
print ("####################### HELP ########################")
print ("Keep output.xlsx with the script")
print ('Example USAGE : ./task.py "URL" "output.xlsx"')
print ('Example USAGE : ./task.py "https://www.wcpss.net/domain/6832" "output.xlsx"')
print ("####################### HELP ########################")
print ("")
print ("")
print ("")

url = sys.argv[1]
output = sys.argv[2]


###########################################################################################################################################

def remove_log(logfile):
	if os.path.isfile(logfile):
		os.remove(logfile)
		
remove_log('log.txt')
remove_log('done.txt')
	
file = codecs.open('log.txt','w',encoding="utf-8")

if not os.path.isfile(output):
	print ("")
	print ("")
	print ("Empty output xlsx Excel file file Not found")
	file.write("Empty output xlsx Excel file file Not found" + '\n' + '\n')
	print ("")
	print ("")
	print ("Please keep Empty output xlsx Excel file file with tool")
	file.write("Please keep Empty output xlsx Excel file file with tool" + '\n' + '\n' + "and try again ....")
	print ("")
	print ("")
	sys.exit()


try:
	df = pd.read_html(url)

except:
	file.write("Tool could not open the link. Something went wrong !!!. Please check the link passed in the input.txt. Please make sure webpage has html Tables to extract !!!" + '\n' + '\n')
	sys.exit()

file_2 = codecs.open('done.txt','w',encoding="utf-8")

def pd_html_excel():

	book = load_workbook(output)
	writer = ExcelWriter(output, engine='openpyxl') 	
	writer.book = book
	writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

	for x in range(0,len(df)):

		df[x].to_excel(writer,sheet_name="table_" + str(x),index=False,header=False)
	
	writer.save()

	file_2.write("Success !!! Please check output xlsx Excel file file for extracted tables from the webpage." + '\n' + '\n')
	print ("Success !!! Please check output xlsx Excel file file for extracted tables from the webpage." + '\n' + '\n')



pd_html_excel()

file.close()
remove_log('log.txt')
