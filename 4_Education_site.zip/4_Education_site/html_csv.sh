#!/bin/sh

rm -Rf csv
chmod -R 777 *.html
./html2csv.py "arts.html"
./html2csv.py "cte.html"
./html2csv.py "english.html"
./html2csv.py "ec.html"
./html2csv.py "foreignlanguage.html"
./html2csv.py "math.html"
./html2csv.py "rotc.html"
./html2csv.py "pe.html"
./html2csv.py "science.html"
./html2csv.py "socialstudies.html"
./html2csv.py "studentservices.html"
./html2csv.py "supportstaff.html"
chmod -R 777 *.csv
mkdir csv
mv *.csv csv
chmod -R 777 csv
rm -Rf *.html
