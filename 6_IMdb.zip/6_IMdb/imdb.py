#!/usr/bin/python3

import urllib3
from bs4 import BeautifulSoup
import pandas as pd
import html5lib
import codecs
import re
import os
from config import config
import sys

'''
Ubuntu - 18.10
python3
Update config.py with imdb link eg :Top Rated English Movies ,Top Rated Indian Movies  from IMDb Chart list
PURPOSE : Python script to download imdb information (data & images)
Run ./img.sh to download images
'''

#Defining empty list
Title = []
rating_score = []
cast = []
img = []


url_1 = config.url_1
url_1 = url_1.strip().strip(chr(10))

'''creating soup object'''
http = urllib3.PoolManager()
response = http.request('GET', url_1)
soup = BeautifulSoup(response.data.decode('utf-8'),"lxml")

def imdb_info():

    for info in soup.findAll('td', {'class': 'titleColumn'}):
 
        #title - Tag value
        title = info.find('a')
        Title.append(title.text)

        #Cast (Values in dictionary objects can be extracted using its key)
        cast.append(title.attrs['title'])

    for info in soup.findAll('td', {'class': 'ratingColumn imdbRating'}):
 
        #rating
        rating = info.find('strong')
        rating_score.append(rating.text)

    os.system('rm -Rf img.sh')    
    count = 0
    for p in soup.findAll('td', {'class': 'posterColumn'}):
        #image link 
        pic = p.img['src']
        img.append(p.img['src'])
        os.system("echo wget -O images/" + str(count) + ".jpg " + pic + " >> img.sh")
        count = count + 1

    os.system('rm -Rf images')    
    os.system('mkdir images')
    os.system('chmod -R 777 img.sh')
    os.system('chmod -R 777 images')


    df = pd.DataFrame({"Title/Movie Name":Title,"Cast":cast,"Rating Score":rating_score,"Image Link":img})
    df.to_excel("Output.xlsx",index=True)
    os.system('chmod -R 777 Output.xlsx')
    os.system('echo chmod -R 777 > img.sh')

 
# calling main function
imdb_info()







