chmod -R 777
