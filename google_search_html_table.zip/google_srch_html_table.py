#!/usr/bin/python

from bs4 import BeautifulSoup
import requests
import config
import pandas as pd
from pandas import ExcelWriter
from openpyxl import load_workbook
import xlsxwriter
import sys

'''
https://stackoverflow.com/questions/47928608/how-to-use-beautifulsoup-to-parse-google-search-results-in-python 
search_item = 'marijuana sales data'  ## search query
url = "https://www.google.co.in/search?q=" + search_item
'''

#reading url from config file
url = config.SEARCH_URL.strip()

# Getting the webpage, creating a Response object.
response = requests.get(url)

# Extracting the source code of the page.
data = response.text

# Passing the source code to BeautifulSoup to create a BeautifulSoup object for it.
soup = BeautifulSoup(data, 'lxml')

#Function to create Excel Workbook
def create_excel(filename):
    workbook = xlsxwriter.Workbook(filename + '.xlsx')
    worksheet = workbook.add_worksheet()
    workbook.close()

# Extracting all the links with class:'r' (inspect element and update accordingly if required)
for g in soup.find_all(class_='r'):
    #URL in the search results converted to string
    g = str(g)
    #cleaning the link string
    link = g.split('&amp')[0].replace('<h3 class="r"><a href="/url?q=',"")
    #creating title for Excel workbook
    title = link.split('//')[1].replace("/","").replace(".","")

    try:
        df = pd.read_html(link)
        if len(df) >= 1:
            #calling function to create Excel Workbook
            create_excel(title)
            # Load excel Workbook using openpyxl
            book = load_workbook(title + '.xlsx')
            writer = ExcelWriter(title + '.xlsx', engine='openpyxl')
            writer.book = book
            writer.sheets = dict((ws.title, ws) for ws in book.worksheets)
            for x in range(0, len(df)):
                df[x].to_excel(writer, sheet_name="table_" + str(x),index=False)
        writer.save()
    except:
        continue