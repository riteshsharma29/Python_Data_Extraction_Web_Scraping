#!/usr/bin/python

SEARCH_URL = "https://www.google.com/search?q=marijuana+sales+data&oq=marijuana+sales+data&aqs=chrome..69i57j0l5.923j0j8&sourceid=chrome&ie=UTF-8"