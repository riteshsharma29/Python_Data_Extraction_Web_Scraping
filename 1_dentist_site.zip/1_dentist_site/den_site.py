#!/usr/bin/python3

import urllib3
from bs4 import BeautifulSoup
import pandas as pd
import html5lib
import codecs
import re
import os

'''
PURPOSE : Task of extarcting Dentist address & Telephone numbers from Swiss Dentist website
#--- Ubuntu 18.10 -----
'''

url_1 = "https://www.sso.ch/index.php?action=search&id=257&L="
url_2 = "&name=&plz=&ort=&radius=0&spez=&wba=&schwerpunkt=&dienstleistung=&verkehr=&sprache="

#Defining empty list 

field_1 = []
field_2 = []
field_3 = []
field_4 = []

'''1st page starts from 0
change 1 to any other 
digit based on the requirement 
make sure page exists'''

for page in range(0,4):

    baseurl = url_1 + str(page) + url_2
    http = urllib3.PoolManager()
    response = http.request('GET', baseurl)
    soup = BeautifulSoup(response.data.decode('utf-8'),"lxml")
    for sec in soup.findAll("div",{"class":"dentist_address dentist_row"}):
        sec = str(sec)
        f = sec.split("<br/>")
        f[0] = f[0].replace('<div class="dentist_address dentist_row">',"")
        field_1.append(f[0])
        f[1] = f[1].replace('<b>',"").replace('</b>',"")
        field_2.append(f[1])
        f[2] = f[2].replace('</div>',"")
        field_3.append(f[2])

    for ssec in soup.findAll("div",{"class":"dentist_contact dentist_row"}):

        #extracting telephone numbers using re module
        t = re.findall('\d+', ssec.text)
        field_4.append(" ".join(t))

#DataFrame creation
df = pd.DataFrame({"FIELD1":field_1,"FIELD2":field_2,"FIELD3":field_3,"TEL":field_4})


#Extracting DataFrame
df.to_excel("sample.xlsx")

os.system('chmod -R 777 sample.xlsx')
