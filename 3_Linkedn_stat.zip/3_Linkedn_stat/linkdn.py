#!/usr/bin/python3

import urllib3
from bs4 import BeautifulSoup
import pandas as pd
import html5lib
import codecs
import re
import os
from config import config
import sys

'''
Ubuntu 18.10
Python3
PURPOSE : Script to convert Linkedin Profile statistics into JSON data
Update config/config.py with profile link
'''

url_1 = config.url_1
url_1 = url_1.strip().strip(chr(10))
url_2 = config.url_2
url_2 = url_2.strip().strip(chr(10))

#######################################################################################################################################

#func to convert time into require format

def cal_time(w,h,d):

    import datetime
    now = datetime.datetime.now()
    format_iso_now = now.isoformat()

    from datetime import timedelta
    later = now + timedelta(weeks=int(w),days=int(d),hours=int(h))
    format_later_iso = later.isoformat()

    #print(format_iso_now, format_later_iso)

    return (now.strftime('%Y-%m-%d %H:%M:%S:%fZ'))

#######################################################################################################################################

#func to generate json output

def gen_json(pic,prof_name,wrkarea,prof_lnk,follwer,posts,article,postdt,mytime,like_1,comnt):

     jsonf = codecs.open("sample.json", "w", encoding="utf8")
     jsonf.write("{" + chr(10))
     jsonf.write(chr(9) + '"profilePictureUrl":"' + pic + '",' + chr(10))
     jsonf.write(chr(9) + '"userName":"' + prof_name + '",' + chr(10))
     jsonf.write(chr(9) + '"userJobTitle":"' + wrkarea + '",' + chr(10))
     jsonf.write(chr(9) + '"profileLink":"' + prof_lnk + '",' + chr(10))
     jsonf.write(chr(9) + '"followers":' + follwer + ',' + chr(10))
     jsonf.write(chr(9) + '"posts":' + posts + ',' + chr(10))
     jsonf.write(chr(9) + '"articles":' + article + ',' + chr(10))
     jsonf.write(chr(9) + '"postedOn":"' + mytime + '",' + chr(10))
     jsonf.write(chr(9) + '"likes":' + like_1 + ',' + chr(10))
     jsonf.write(chr(9) + '"comments":' + comnt  + chr(10))
     jsonf.write("}" + chr(10))
     os.system('chmod -R 777 sample.json')

#######################################################################################################################################

'''creating soup object'''

baseurl = url_1 + str(url_2)
http = urllib3.PoolManager()
response = http.request('GET', baseurl)
soup = BeautifulSoup(response.data.decode('utf-8'),"lxml")

def linkdn_stat():

    #profile link
    for div in soup.findAll('div', {'class': 'left-rail'}):
        a = div.findAll('a')[1]
        prof_lnk = a.attrs['href']
    #profile pic
        i = div.findAll('img')[0]
        pic = i.attrs['data-delayed-url']
    
    #Profile Name
    prof_name = soup.find('h3').text

    #Workarea
    wrkarea = soup.find('h4').text
    wrkarea = wrkarea.replace(chr(10),"").strip()

    #Followerscount
    follwers = soup.find('p').text
    follwer = follwers.replace(" Followers","")

    #Post
    post = soup.find("a",{"class":"author-profile__anchor"})
    posts = post.text.replace("Posts","")

    #Article
    artcl = soup.find("ul",{"class":"author-profile__author-stats"})
    article = artcl.text.replace("Articles","").replace(posts,"")
    article = article.replace('Posts',"")

    #Likes (combination of likes + comments)
    likes = soup.find("div",{"class":"share-update-card__social-counts public-post__social-counts"})
    like = likes.text.split(" Likes")
    like_1 = str(like[0])

    #Comments
    comment = str(like[1])
    comnt = comment.replace(" Comments","")

    #postdate
    postdate = soup.find("time",{"class":"share-update-card__post-date public-post__post-date"})
    postdt = postdate.text

    #time conversion
    if "w" in postdt:
        postdt = postdt.replace("w · Edited","")
        w = postdt
        mytime=cal_time(w,0,0)
    if "h" in postdt:
        postdt = postdt.replace("h · Edited","")
        h = postdt
        mytime=cal_time(0,h,0)
    if "d" in postdt:
        postdt = postdt.replace("d · Edited","")
        d = postdt
        mytime=cal_time(0,0,d)
    
    #Calling json generation function
    gen_json(pic,prof_name,wrkarea,prof_lnk,follwer,posts,article,postdt,mytime,like_1,comnt)


# calling main function
linkdn_stat()








