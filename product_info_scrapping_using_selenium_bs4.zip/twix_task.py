#!/usr/bin/python

'''
USAGE : c:\Python37\python.exe twix_task.py "https://www.target.com/p/twix-mini-s-9-7oz/-/A-53280541"
'''

from selenium import webdriver
from bs4 import BeautifulSoup as bs
import sys
import codecs
import os
import sys
import time

url = sys.argv[1]

file = codecs.open("dump.txt",encoding='utf-8',mode='w')
#Specify chromedriver.exe windows path
driver = webdriver.Chrome(executable_path=os.path.join(os.getcwd(),'drivers\\chromedriver.exe'))    
driver.get(url)
driver.maximize_window()
#write page source into a file
file.write(driver.page_source)
driver.close()

soup = bs(open("dump.txt"), "html.parser")

print ('\n' + '\n' + '\n')

product = soup.find_all('title')[0].text
print ("Title - " + product.replace(' : Target',""))

price = soup.find_all("span", class_="h-text-xl h-text-bold")[0].text
print ("Price - " + price)


f = open("dump.txt",'r',encoding='utf-8')
c = f.read()
#returns the int value of string itemDetails found in dump.txt
i = c.find('itemDetails') 
#required string
fndstr = c[i+15:181947]
#split and extract required string
x = fndstr.split(",")
#print(x,fndstr)
try:
    print (x[0].upper().replace('"',""))
    print(x[2].replace('"',"").replace("dpci","Item Number (DPCI): "))
except:
    pass	





