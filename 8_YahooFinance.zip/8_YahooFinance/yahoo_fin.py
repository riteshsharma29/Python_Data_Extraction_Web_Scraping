#!/usr/bin/python3

import urllib3
from bs4 import BeautifulSoup
import pandas as pd
import html5lib
import os
import sys

'''
PURPOSE : Python3 Pandas & beautifulsoup web scraping of yahoo stock data
TESTED on Ubuntu 18.10 platform
'''


#defining empty list
stock = []
#Latest Quarter
lq = []
#Previous Quarter
pq = []
#Current Quarter avg estimate
cqae= []
#Next Quarter avg estimate
nqae= []

df = pd.read_excel('input.xlsx',sheet_name='Sheet1')
company = df['Company Symbol'].values.T.tolist()


#for c in range(0,3):
for c in range(0,df.shape[0]):

    stock.append(company[c])


################################# Financials ############################################## 

    try:
        finance_url =  'https://in.finance.yahoo.com/quote/' + str(company[c]).strip() + '/financials?p=' + str(company[c]).strip()
        f = pd.read_html(finance_url)
        #converting 1st table values into a list
        val = f[0].values.T.tolist()
        lq.append(val[1][0])
        pq.append(val[2][0])
    except :
        lq.append(' ')
        pq.append(' ')

################################# Analysis ############################################## 

    #converting 2nd table values into a list
    try:
        analysis_url =  'https://in.finance.yahoo.com/quote/' + str(company[c]).strip() + '/analysis?p=' + str(company[c]).strip()
        a = pd.read_html(analysis_url) 
        val_2 = a[1].values.T.tolist()
        cqae.append(val_2[1][1])
        nqae.append(val_2[2][2])
    except:
        cqae.append(' ')
        nqae.append(' ')

#########################################################################################

opdf = pd.DataFrame({"Company":stock,"Last Quarter":lq,'Previous Quarter':pq,'Current Quarter avg estimate':cqae,"Next Quarter avg estimate":nqae})
opdf.to_csv("Output.csv",index=False)
os.system('chmod -R 777 Output.csv')

print ("done")


