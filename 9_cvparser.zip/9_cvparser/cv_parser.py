#!/usr/bin/python3

import mammoth
import sys
from bs4 import BeautifulSoup
import pandas as pd
import html5lib
import re
import os
import urllib3

'''
PURPOSE : Parsing and extracting basic information from CV/RESUME
18.10
python3
'''

if len(sys.argv) == 1:
    print('\n')
    print('\n')
    print('USAGE : ./cv_parser.py <resume filenamename>')
    print('USAGE : ./cv_parser.py cvtest_1.docx')
    print('\n')
    print('\n')
    sys.exit()

filename = sys.argv[1]
filename = filename.strip()

#flag setting
flag = 0

#A empty list defined
n = []


def doctohtml(filename):

    try:
        f = open(filename, 'rb')
        b = open(filename + '.html', 'wb')
    except:
        print ('Error Occured')
        sys.exit()
    document = mammoth.convert_to_html(f)
    b.write(document.value.encode('utf8'))
    f.close()
    b.close()
    soup = BeautifulSoup(open(filename + '.html'),"lxml")
    os.system('chmod -R 777 ' + filename + '.html')
    ptag = soup.findAll('p') 
    print ('\n')   
    print ('\n')   
    print ('CV / RESUME :' + filename)
    for i in range(0,len(soup.findAll('p'))):
         n.append(ptag[i].text)

#calling function to convert docx/doc cv to html file
doctohtml(filename)

for x in range(0,len(n)):    
    if '@' in n[x] and "linkedin" in n[x]:
       flag = 1
       #split by space
       emlstr = str(n[x]).split()
       for a in range(0,len(emlstr)):
           if "@" in emlstr[a]:
               email = emlstr[a].lower().replace('email:',"").replace('id',"")
               print ('EMAIL ID:' +  email)
           if "linkedin" in emlstr[a]:
               lndn = emlstr[a]  
               print ('LinkedIn URL :' + lndn)   
               phone =  str(n[x]).replace(email,"").replace(lndn,"")    
               phone = phone.replace('|',"").replace(' ',"").replace(',',"") 
               print ('Contact Number :' + phone) 
               print ('\n')
               print ('\n')            
       if flag == 1: 
           os.system('rm -Rf ' + filename + '.html')
           sys.exit()   



#phone #
for x in range(0,len(n)):
    n[x] = n[x].replace('\t',"").replace(' ',"")
    if '+' in n[x]:
        print(n[x])
        break
    #regex for phone number
    t = re.findall('\d+', n[x])
    ret = ",".join(t)
    if len(str(ret).replace(",","")) == 10:
        phone = ret.replace('|',"").replace(' ',"").replace(',',"")
        print ('Contact Number :' + phone) 
    if len(str(ret).replace(",","")) >= 10:
        phone = ret.replace('|',"").replace(' ',"").replace(',',"")
        print ('Contact Number :' + phone) 
        break

#email
for x in range(0,len(n)):    
    if '@' in n[x]:
       #split by space
       emlstr = str(n[x]).split()
       for a in range(0,len(emlstr)):
           if "@" in emlstr[a]:
               email = emlstr[a].lower().replace('email:',"").replace('id',"")
               print ('Email :' + email) 
               break

#linkedin url
for l in range(0,len(n)):    
    if 'linkedin' in n[l]:
       #split by space
       lnkstr = str(n[l]).split()
       for b in range(0,len(lnkstr)):
           if "linkedin" in lnkstr[b]:
               lndn = lnkstr[b]
               print ('LinkedIn URL :' + lndn)   
               print ('\n')            
               break

print ('\n')  
#Delet the html file after parsing 
os.system('rm -Rf ' + filename + '.html')
