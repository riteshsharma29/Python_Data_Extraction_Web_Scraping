#!/usr/bin/python3

import urllib3
from bs4 import BeautifulSoup
import pandas as pd
import html5lib
import codecs
import re
import os
from config import config
import sys
import re

'''
Ubuntu - 18.10
Update config.py with Exhibition Site link till = sign exclude page number
PURPOSE : Downloads exhibition site data into excel sheet
'''

#Defining empty list
name = []
exposant = []
e_date = []
contact = []
company = []


url_1 = config.url_1
url_1 = url_1.strip().strip(chr(10))

#Range for pages
for page in range(1,25):

    baseurl = url_1 + str(page)
    http = urllib3.PoolManager()
    response = http.request('GET', baseurl)
    soup = BeautifulSoup(response.data.decode('utf-8'),"lxml")

    print (page)

    #Range for 10 articles per page
    for i in range(0,10):

       #Exhibition Name 
       try:
           n = soup.findAll("h3",{"class":"Article-line-title"})[i].text
           n = str(n).replace(chr(10),"")
           name.append(n)
       except:
           name.append(" ")
    
       #Date
       try:
           Dates = soup.findAll("div",{"class":"Article-line-meta date"})[i].text
           Date = Dates.strip().replace(chr(10),"")
           d = re.sub(' +', ' ',Date)
           e_date.append(d)
       except:
           e_date.append(" ")

       #exponant
       try:
           Exps = soup.findAll("header",{"class":"Article-line-heading"})[i].text
           e = Exps.split(chr(10))
           e_I = str(e[5]).strip()
           e_II = str(e[6]).strip()
           e_III = str(e[7]).strip()
           e = e_I + e_II + e_III
           e_list = e.split('|')
           if len(e_list) == 2:
               e_built = str(e_list[0]).strip() + " | " + str(e_list[1]).strip()
               exposant.append(e_built)
           if len(e_list) == 3: 
               e_built = str(e_list[0]).strip() + " | " + str(e_list[1]).strip() + " | " + str(e_list[2]).strip()
               exposant.append(e_built)
       except:
           exposant.append(" ")

       #contact
       try:
           c = soup.findAll("div",{"class":"Article-line-place"})[i].text
           contact.append(c)
       except:
           contact.append(" ")


       #contact
       try:
           co = soup.findAll("div",{"class":"Article-line-content"})[i].text
           company.append(co)
       except:
           company.append(" ")
        

df = pd.DataFrame({"Name of Exhibition":name,"Date of Exhibition":e_date,"Name of Exposant":exposant,"Full Contact Details":contact,"Explanation":company})
df.to_excel("Exhibition.xlsx") 
os.system("chmod -R 777 Exhibition.xlsx")


