#!/usr/bin/python

import unittest
from selenium import webdriver
from bs4 import BeautifulSoup as bs
import codecs
import pandas as pd
import sys
import time

'''
Ubuntu 12.04
Python2.7
'''

#Update input filename below
Input_filename = "input.xlsx"

df = pd.read_excel(Input_filename,sheetname='Sheet1')

name = df['Complete Name'].values.T.tolist()
eml = df['EmailID'].values.T.tolist()
company = df['Company Name'].values.T.tolist()

Name=[]
Email = []
Company=[]
Title=[]
URL=[]
DESC=[]

#Specify chromedriver.exe windows path
#driver = webdriver.Chrome(executable_path=r'D:\up_task\chromedriver.exe')     
#specify chromedriver.exe linux path
driver = webdriver.Chrome(executable_path=r'/root/Desktop/webs/chromedriver')    


#for i in range(0,df.shape[0]):
for i in range(0,1000):
    Name.append(name[i])
    Email.append(eml[i])    
    Company.append(company[i])

#for i in range(0,df.shape[0]):
for i in range(0,1000):

    comp = str(company[i]).lower().replace("private limited","").replace("limited","").replace("pvt","").replace("ltd.","")

    #delay 
    time.sleep(4)  
    results = driver.get('https://www.google.com/search?q=' + name[i] + ',Linkedin,' + str(comp).strip())
    html = driver.page_source
    soup = bs(html,"lxml")

    #handling no results found scenario
    for val in soup.find_all('p'):        
        if "Your search -" in val.text:
             Title.append('search not found')
             URL.append('search not found')
             DESC.append('search not found')    
    try:
        for title in soup.find_all('h3'):
            Title.append(title.text)
            break
    except:
        Title.append(' ')
		
    try: 
        for link_text in soup.find_all('cite'):
            URL.append(link_text.text)
            break
    except:
        URL.append(' ')		
		
    try:
        spans = soup.find_all('span', {'class': 'st'})
        # create a list of lines corresponding to element texts
        lines = [span.get_text() for span in spans]
        for desc in lines:
            DESC.append(desc)
            break
    except:
	    DESC.append(' ')
	
driver.close()

#for debugging
#print len(Name),len(Email),len(Company),len(Title),len(URL),len(DESC)

opdf = pd.DataFrame({"Name":Name,"Email":Email,'Company':Company,'Title':Title,'URL':URL,"DESCRIPTION":DESC})
opdf.to_excel("Output.xlsx",index=False)

print "done"


