#!/usr/bin/python

import pandas as pd
import sys

'''
Ubuntu 12.04
Python2.7
'''

df = pd.read_excel('Output.xlsx',sheetname='Sheet1')

Comp = df['Company'].values.T.tolist()
desc = df['DESCRIPTION'].values.T.tolist()
email = df['Email'].values.T.tolist()
name = df['Name'].values.T.tolist()
title = df['Title'].values.T.tolist()
link = df['URL'].values.T.tolist()

Name=[]
Email = []
Company=[]
Title=[]
URL=[]
DESC=[]

for i in range(0,df.shape[0]):
 
    firstname = name[i].split()
    Compy = Comp[i].split()
    Compy = Compy[0].replace(".","") 
    tmpname = name[i].lower()
    #first_name
    n_str = tmpname.split()
    #if "linkedin" in link[i] and not "pub" in link[i] or n_str[0] in desc:
    if "linkedin" in link[i] and not "pub" in link[i] and not "company" in link[i] and "https" in link[i]:
       if n_str[0] in str(desc).lower():
           Name.append(name[i])
           Email.append(email[i])
           Company.append(Comp[i])
           Title.append(title[i])
           URL.append(link[i])
           DESC.append(desc[i])

opdf = pd.DataFrame({"Name":Name,"Email":Email,'Company':Company,'Title':Title,'URL':URL,"DESCRIPTION":DESC})
opdf.to_excel("filter_output.xlsx",index=False)

print "done"


